import pygame
import random
import sys

AnchoImG = 72
AltoImg = 90

ANCHO=800
ALTO=600

BLANCO=(255,255,255)
NEGRO=(0,0,0)
ROJO=(255,0,0)
VERDE=(0,255,0)
AZUL=(0,0,255)

def pendiente(x0,x1,y0,y1):
    dy=y1-y0
    dx=x1-x0
    m=int(dy/dx)
    return m
def fun_rect(m,x0,x1,yo,y1):
    m=pendiente(x0,x1,y0,y1)
    y= m*x+y0

class Player1(pygame.sprite.Sprite):
    def __init__(self, archivoimagen):
        pygame.sprite.Sprite.__init__(self)
        #self.image=pygame.Surface([alto,ancho])
        #self.image=pygame.image.load(archivoimagen).convert_alpha()#el convert hace efectiva la transparencia
        #self.image.fill(color)
        self.image=archivoimagen
        self.rect=self.image.get_rect()
        self.rect.y=300
        self.rect.x=400
        self.var_x=10
        self.var_y=10
        self.dir=0#cero para desplazarse a la derecha y uno para la izquierda
        self.fps=0
        self.gravity=0

    def update(self):
        if self.fps <7:
            self.fps+=1
        else:
            self.fps=0
        if self.dir==0:
            self.rect.x += self.var_x
        if self.dir==1:
            self.rect.x -= self.var_x
        if self.dir==2:
            self.rect.y -= self.var_y*4
        if self.dir==3:
            self.rect.y += self.var_y
        self.dir=5
        '''if self.rect.bottom < 580:
            self.rect.y+=4
        else:
            self.rect.bottom=580'''

class Misil(pygame.sprite.Sprite):
    def __init__(self, archivoimagen):
        pygame.sprite.Sprite.__init__(self)
        #self.image=pygame.Surface([alto,ancho])
        self.image=pygame.image.load(archivoimagen).convert_alpha()#el convert hace efectiva la transparencia
        #self.image.fill(color)
        self.rect=self.image.get_rect()
        self.rect=self.image.get_rect()
        self.der=0
        self.vel=2
        self.temp=random.randint(50,150)
        self.mover=0
        self.x=0
        self.y=0
        self.m=0
        self.xf=0
        self.yf=0

    def Mover(self, pos):
        if self.mover==0:
            self.mover=1
            self.xf=pos[0]
            self.yf=pos[1]
            self.x=self.rect.x
            self.y=self.rect.y
            dx=float(self.xf-self.rect.x)
            dy=float(self.yf-self.rect.y)
            self.m=dy/dx
            print self.m

    def update(self):
        if self.mover==1:
            if self.x < self.xf:
                self.x+=1
                self.y+=self.m
                self.rect.x=self.x
                self.rect.y=int(self.y)




if __name__ == '__main__':
    pygame.init()
    pantalla= pygame.display.set_mode([ANCHO,ALTO])
    fondo= pygame.image.load("fondo.jpg")
    goku=pygame.image.load("CompleteBoy.png").convert_alpha()
    #broly=pygame.image.load("Broly1.png").convert_alpha()
    todos= pygame.sprite.Group()
    #player13=Player1("goku24.png")

    cuadro=goku.subsurface(0,0,51,51,)
    gamer=Player1(cuadro)
    #enemy = Enemigo(broly.subsurface(0,0,200,200))

    todos.add(gamer)

    reloj = pygame.time.Clock()
    fin= False
    while not fin:
        #Capturar eventos
        pos=pygame.mouse.get_pos()
        #pygame.mouse.set_visible(False)
        #pos=pygame.mouse.get_pos()
        for event in pygame.event.get():
            if event.type==pygame.KEYDOWN:
                if event.key==pygame.K_RIGHT:
                    gamer.dir=0
                    gamer.image=goku.subsurface(gamer.fps*51,144,51,72)
                if event.key==pygame.K_LEFT:
                    gamer.dir=1
                    gamer.image=goku.subsurface(0+(51*gamer.fps),72,51,72)
                if event.key==pygame.K_UP:
                    gamer.dir=2
                    gamer.image=goku.subsurface(0+(51*gamer.fps),216,51,72)
                if event.key==pygame.K_DOWN:
                    gamer.dir=3
                    gamer.image=goku.subsurface(0+(51*gamer.fps),0,51,72)
                if event.key==pygame.K_SPACE:
                    gamer.dir=4
                    gamer.image=goku.subsurface(gamer.fps*51,144,51,72)
                if event.key==pygame.K_b:
                    gamer.image=goku.subsurface(gamer.fps*51,72,51,72)
            if event.type== pygame.MOUSEBUTTONDOWN:
                b=Misil('misil.png')
                b.rect.x=gamer.rect.x+30
                b.rect.y=gamer.rect.y+30
                #b.disparoE=1
                b.Mover(pos)
                todos.add(b)

                print pos
            if event.type== pygame.QUIT:
                fin= True
            #enemy.image=broly.subsurface(enemy.fps*200,200,200,200)
            #enemy.pos=[gamer.rect.x,gamer.rect.y]
            #if enemy.disparo==1:
            #    b=Misil('misil.png',[gamer.rect.x+120,gamer.rect.y+120])
                #grito.play()
            #    b.disparoE=0
            #    todos.add(b)
        pantalla.blit(fondo,[0,0])
        #if gamer.rect.bottom != pantalla.get_height():
        #    gamer.gravity()


        todos.draw(pantalla)

        todos.update()
        #pantalla.fill(BLANCO)
        pygame.display.flip()
        reloj.tick(60)
